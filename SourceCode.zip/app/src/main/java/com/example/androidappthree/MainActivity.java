package com.example.androidappthree;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.app.Activity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
ImageView ivPreview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivPreview = (ImageView)  findViewById(R.id.ivPreview);
    }

    public void changeImage(View view){
        switch (view.getId()){
            case R.id.iv_anna:
                ivPreview.setBackgroundResource(R.drawable.marshmallow);
                break;
            case R.id.iv_elsa:
                ivPreview.setBackgroundResource(R.drawable.lollipop);
                break;
            case R.id.iv_olaf:
                ivPreview.setBackgroundResource(R.drawable.nougat);
                break;

        }
    }
}